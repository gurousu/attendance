from setuptools import setup

setup(
    name="attendance_check",
    version='1.0',
    description='1クリックで出退勤',
    author='Daiki Ishiguro',
    author_email='gurousu@gmail.com',
    url='https://github.com/gurousu/python_package',
)
